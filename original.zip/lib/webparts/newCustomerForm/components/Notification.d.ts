import * as React from 'react';
import { MessageBarType } from '@fluentui/react';
export interface NotificationProps {
    message: string;
    type?: MessageBarType;
    onDismiss?: () => void;
}
declare const Notification: React.FC<NotificationProps>;
export default Notification;
//# sourceMappingURL=Notification.d.ts.map