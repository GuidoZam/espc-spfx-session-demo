import '@testing-library/jest-dom';
//# sourceMappingURL=NewCustomerForm.test.d.ts.map