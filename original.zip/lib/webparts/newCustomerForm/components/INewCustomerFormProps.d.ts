export interface INewCustomerFormProps {
    userDisplayName: string;
}
//# sourceMappingURL=INewCustomerFormProps.d.ts.map