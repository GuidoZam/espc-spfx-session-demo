import * as React from 'react';
import type { INewCustomerFormProps } from './INewCustomerFormProps';
declare const NewCustomerForm: React.FC<INewCustomerFormProps>;
export default NewCustomerForm;
//# sourceMappingURL=NewCustomerForm.d.ts.map