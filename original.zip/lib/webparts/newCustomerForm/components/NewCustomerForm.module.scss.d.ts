declare const styles: {
    newCustomerForm: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    customerForm: string;
    formRow: string;
    input: string;
    textarea: string;
    submitBtn: string;
    required: string;
    formError: string;
    fieldError: string;
};
export default styles;
//# sourceMappingURL=NewCustomerForm.module.scss.d.ts.map