export interface IHelloWorldProps {
    userDisplayName: string;
}
//# sourceMappingURL=IHelloWorldProps.d.ts.map