import '@testing-library/jest-dom';
//# sourceMappingURL=HelloWorld.test.d.ts.map