declare const styles: {
    helloWorld: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    customerForm: string;
    formRow: string;
    input: string;
    textarea: string;
    submitBtn: string;
    required: string;
    formError: string;
    fieldError: string;
};
export default styles;
//# sourceMappingURL=HelloWorld.module.scss.d.ts.map