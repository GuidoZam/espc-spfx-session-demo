import * as React from 'react';
import type { IHelloWorldProps } from './IHelloWorldProps';
declare const HelloWorld: React.FC<IHelloWorldProps>;
export default HelloWorld;
//# sourceMappingURL=HelloWorld.d.ts.map