
require("./NewCustomerForm.module.css");
const styles = {
  newCustomerForm: 'newCustomerForm_da2d2084',
  teams: 'teams_da2d2084',
  welcome: 'welcome_da2d2084',
  welcomeImage: 'welcomeImage_da2d2084',
  customerForm: 'customerForm_da2d2084',
  formRow: 'formRow_da2d2084',
  input: 'input_da2d2084',
  textarea: 'textarea_da2d2084',
  submitBtn: 'submitBtn_da2d2084',
  required: 'required_da2d2084',
  formError: 'formError_da2d2084',
  fieldError: 'fieldError_da2d2084'
};

export default styles;
